
// This code loads the IFrame Player API code asynchronously.
var tag = document.createElement('script');

tag.src = "https://www.youtube.com/iframe_api";
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

// This function creates an <iframe> (and YouTube player)
// after the API code downloads.
var player;
function onYouTubeIframeAPIReady() {
    player = new YT.Player('playerCampanha', {
        height: '315',
        width: '560',
        videoId: '5iQV_de92SU',
        playerVars: {
            'showinfo': 0,
            'rel': 0,
            'wmode': 'transparent'
        },
        events: {
            //'onReady': onPlayerReady
        }

    });
}

function onPlayerReady(event) {
    
}


$(function(){

    $(".video-campanha").click(function(){
        $(this).hide();
        player.stopVideo();
    });

    $(".chamadas .campanha a").click(function(event){
        event.preventDefault();
        $(".video-campanha").show();
        $('html, body').animate({
            scrollTop: $(".video-campanha .video").offset().top - 40
        }, 1000);
        player.playVideo();
    });

});
